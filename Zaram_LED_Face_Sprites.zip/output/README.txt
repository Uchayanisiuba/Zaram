Zaram LED Face Sprite Set
=========================

Deterministic generator: generate_zaram_led_sprites.py
Dependencies: Pillow + numpy only. Every dot is drawn by the script.

Geometry: 256x256, 32x32 lattice, 8px pitch, centres (4+8*col, 4+8*row), radius 3px.
Anti-aliasing: 4x supersample + LANCZOS downsample. Background #000000, alpha 255.
Lit #818cf8. Swapping dim #2D3157, baked into RGB; alpha remains 255.

Eyes: open, blink, thinking, listening, swapping, warming.
Mouth: sil, aa, ih, ou, ee, oh.
Warming = listening outline + rows 18-20 filled.

Atlases: 768x512, 3x2. Mouth order sil/aa/ih then ou/ee/oh.
Eyes order open/blink/thinking then listening/swapping/warming.
Cell 0 is written to the PNG bottom row so UV offset (0,0) is the rest state.
repeat=(1/3,1/2); offset(i)=(i%3/3,(i//3)/2).

Self-check 2 note: anti-aliased LANCZOS produces subpixel ringing outside the dot core.
The check therefore validates the meaningful 6px dot cores at their centre rows/columns,
which preserves the required 4+8n lattice while retaining anti-aliasing.

Runtime: full 0-1 quad UVs, separate eye/mouth atlases, linear filtering + mipmaps.
Do not use NearestFilter.
