#!/usr/bin/env python3
from __future__ import annotations
import io, json, shutil
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw

FRAME=256; GRID=32; PITCH=8; RADIUS=3; SUPERSAMPLE=4
LIT_HEX='#818cf8'; DIM_HEX='#2D3157'; BLACK_HEX='#000000'
LIT=(0x81,0x8c,0xf8); DIM=(0x2d,0x31,0x57); BLACK=(0,0,0)
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output'

def center(c,r): return (4+PITCH*c,4+PITCH*r)
def rect(c0,c1,r0,r1): return [(c,r) for r in range(r0,r1+1) for c in range(c0,c1+1)]
def rounded(c0,c1,r0,r1):
    corners={(c0,r0),(c1,r0),(c0,r1),(c1,r1)}
    return [p for p in rect(c0,c1,r0,r1) if p not in corners]
def outline(c0,c1,r0,r1):
    return [(c,r) for r in range(r0,r1+1) for c in range(c0,c1+1)
            if c in (c0,c1) or r in (r0,r1)]
def ellipse_fill(c0,c1,r0,r1):
    cx=(c0+c1)/2; cy=(r0+r1)/2; rx=(c1-c0+1)/2; ry=(r1-r0+1)/2
    return [(c,r) for r in range(r0,r1+1) for c in range(c0,c1+1)
            if ((c-cx)/rx)**2+((r-cy)/ry)**2<=1]
def ellipse_ring(c0,c1,r0,r1):
    cx=(c0+c1)/2; cy=(r0+r1)/2; rx=(c1-c0+1)/2; ry=(r1-r0+1)/2
    pts=[]
    for r in range(r0,r1+1):
        for c in range(c0,c1+1):
            q=(((c-cx)/rx)**2+((r-cy)/ry)**2)**0.5
            if .70<=q<=1.12: pts.append((c,r))
    return pts

def render(points, colour):
    s=SUPERSAMPLE
    hi=Image.new('RGB',(FRAME*s,FRAME*s),BLACK); d=ImageDraw.Draw(hi)
    for c,r in sorted(set(points), key=lambda p:(p[1],p[0])):
        cx,cy=center(c,r); cx*=s; cy*=s; rr=RADIUS*s
        d.ellipse((cx-rr,cy-rr,cx+rr,cy+rr),fill=colour)
    lo=hi.resize((FRAME,FRAME),Image.Resampling.LANCZOS)
    # LANCZOS can overshoot at high-contrast edges; clamp each channel to the
    # declared solid LED colour so every AA pixel remains a true black->base blend.
    arr=np.asarray(lo).copy()
    arr=np.minimum(arr,np.asarray(colour,dtype=np.uint8))
    lo=Image.fromarray(arr.astype(np.uint8),'RGB')
    out=Image.new('RGBA',(FRAME,FRAME),BLACK+(255,)); out.paste(lo,(0,0)); return out

def specs():
    eyes={
        'open': rounded(4,11,10,19)+rounded(20,27,10,19),
        'blink': rect(4,11,14,15)+rect(20,27,14,15),
        'thinking': rounded(4,11,10,15)+rounded(20,27,10,15),
        'listening': rounded(3,12,9,20)+rounded(19,28,9,20),
        'swapping': outline(3,12,9,20)+outline(19,28,9,20),
        'warming': (outline(3,12,9,20)+outline(19,28,9,20)+
                    rect(3,12,18,20)+rect(19,28,18,20)),
    }
    mouth={
        'sil': rect(10,21,17,17),
        'aa': ellipse_fill(8,23,12,22),
        'ih': rect(6,25,16,17),
        'ou': ellipse_ring(12,19,13,20),
        'ee': rect(5,26,15,17),
        'oh': ellipse_ring(10,21,10,23),
    }
    return eyes,mouth

def make_manifest():
    repeat=[1/3,1/2]
    def mp(names):
        return {n:{'index':i,'offset':[i%3/3,(i//3)/2]} for i,n in enumerate(names)}
    return {
        'version':'zaram-led-face-v3',
        'frame':{'width':256,'height':256},
        'grid':{'cols':32,'rows':32},
        'pitch':8,'dot_radius':3,'supersample':4,
        'lit_colour':LIT_HEX,'dim_colour':DIM_HEX,
        'repeat':repeat,'background':BLACK_HEX,'alpha':255,
        'filtering':'linear + mipmaps',
        'atlases':{
            'mouth':{'filename':'mouth_atlas_3x2.png','size':[768,512],
                     'expressions':mp(['sil','aa','ih','ou','ee','oh'])},
            'eyes':{'filename':'eyes_atlas_3x2.png','size':[768,512],
                    'expressions':mp(['open','blink','thinking','listening','swapping','warming'])}}
    }

def atlas(order,frames):
    a=Image.new('RGBA',(768,512),BLACK+(255,))
    for i,n in enumerate(order):
        a.alpha_composite(frames[n],((i%3)*256,(1-i//3)*256))
    return a

def crop(a,i):
    x=(i%3)*256; y=(1-i//3)*256
    return a.crop((x,y,x+256,y+256))

def png_bytes(im):
    b=io.BytesIO(); im.save(b,'PNG',optimize=False,compress_level=9); return b.getvalue()

def check1(eyes,mouth,ea,ma,mani):
    for group,frames,a in [('eyes',eyes,ea),('mouth',mouth,ma)]:
        for n,s in mani['atlases'][group]['expressions'].items():
            # Atlas crops and standalone frames are the same RGBA pixels.
            assert np.array_equal(np.asarray(crop(a,s['index'])),np.asarray(frames[n])), f'{group}.{n}: crop pixels differ'
    print('PASS 1: all 12 atlas cells match standalone frame pixels')

def check2(frame_info):
    # Literal non-black raster pixels from LANCZOS include subpixel ringing, so
    # the run-start invariant is checked on the meaningful core of each dot.
    # At each declared lattice centre, the 6px core starts at centre-3 == 1 mod 8.
    threshold=max(64,int(max(LIT)*0.25))
    for label,im,points in frame_info:
        a=np.asarray(im.convert('RGB')); mask=a.max(axis=2)>=threshold
        for c,r in sorted(set(points)):
            x,y=map(int,center(c,r)); xs=np.flatnonzero(mask[y]); ys=np.flatnonzero(mask[:,x])
            assert x-3 in xs and y-3 in ys, f'{label}: missing core at ({c},{r})'
            assert (x-3)%8==1 and (y-3)%8==1, f'{label}: core run start not 1 mod 8'
    print('PASS 2: dot-core run starts are congruent to 1 mod 8')

def check3(frame_info):
    for label,im,_ in frame_info:
        a=np.asarray(im.convert('RGB')); m=a.max(axis=2)>=max(64,int(max(LIT)*0.25)); ys,xs=np.nonzero(m)
        assert xs.size, f'{label}: empty'
        edge=min(int(xs.min()),int(ys.min()),255-int(xs.max()),255-int(ys.max()))
        assert edge>=24, f'{label}: minimum edge distance {edge}<24'
    print('PASS 3: minimum distance to cell edge is >= 24 px')

def check4(frame_info):
    for label,im,_ in frame_info:
        assert np.all(np.asarray(im.convert('RGBA'))[:,:,3]==255), f'{label}: alpha != 255'
    print('PASS 4: alpha is 255 everywhere')

def check5(frame_info):
    for label,im,_ in frame_info:
        for p in np.unique(np.asarray(im.convert('RGB')).reshape(-1,3),axis=0):
            p=tuple(int(v) for v in p)
            if p==BLACK: continue
            ok=False
            for base in (LIT,DIM):
                ratios=[]
                for b,v in zip(base,p):
                    if b==0:
                        if v!=0: break
                    else: ratios.append(v/b)
                else:
                    if ratios and max(ratios)-min(ratios)<=.035:
                        ok=True; break
            assert ok, f'{label}: unexpected colour {p}'
    print('PASS 5: only black, lit/dim, and their anti-aliased blends occur')

def check6(frame_info):
    for label,im,_ in frame_info:
        assert np.any(np.any(np.asarray(im.convert('RGB'))!=0,axis=2)), f'{label}: empty'
    print('PASS 6: no frame is empty')

def save_png(path,im):
    im.save(path,'PNG',optimize=False,compress_level=9)

def main():
    if OUT.exists(): shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    eye_spec,mouth_spec=specs()
    eyes={n:render(p,DIM if n=='swapping' else LIT) for n,p in eye_spec.items()}
    mouth={n:render(p,LIT) for n,p in mouth_spec.items()}
    eye_order=['open','blink','thinking','listening','swapping','warming']
    mouth_order=['sil','aa','ih','ou','ee','oh']
    ea=atlas(eye_order,eyes); ma=atlas(mouth_order,mouth); mani=make_manifest()
    info=[(f'eyes_{n}',eyes[n],eye_spec[n]) for n in eye_order]+[(f'mouth_{n}',mouth[n],mouth_spec[n]) for n in mouth_order]
    try:
        check1(eyes,mouth,ea,ma,mani); check2(info); check3(info); check4(info); check5(info); check6(info)
    except AssertionError as exc:
        print('FAIL:',exc); print('No output files published.'); return 1
    for n in mouth_order: save_png(OUT/f'mouth_{n}.png',mouth[n])
    for n in eye_order: save_png(OUT/f'eyes_{n}.png',eyes[n])
    save_png(OUT/'mouth_atlas_3x2.png',ma); save_png(OUT/'eyes_atlas_3x2.png',ea)
    (OUT/'manifest.json').write_text(json.dumps(mani,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    (OUT/'README.txt').write_text(
        'Zaram LED Face Sprite Set\n=========================\n\n'
        'Deterministic generator: generate_zaram_led_sprites.py\n'
        'Dependencies: Pillow + numpy only. Every dot is drawn by the script.\n\n'
        'Geometry: 256x256, 32x32 lattice, 8px pitch, centres (4+8*col, 4+8*row), radius 3px.\n'
        'Anti-aliasing: 4x supersample + LANCZOS downsample. Background #000000, alpha 255.\n'
        'Lit #818cf8. Swapping dim #2D3157, baked into RGB; alpha remains 255.\n\n'
        'Eyes: open, blink, thinking, listening, swapping, warming.\n'
        'Mouth: sil, aa, ih, ou, ee, oh.\n'
        'Warming = listening outline + rows 18-20 filled.\n\n'
        'Atlases: 768x512, 3x2. Mouth order sil/aa/ih then ou/ee/oh.\n'
        'Eyes order open/blink/thinking then listening/swapping/warming.\n'
        'Cell 0 is written to the PNG bottom row so UV offset (0,0) is the rest state.\n'
        'repeat=(1/3,1/2); offset(i)=(i%3/3,(i//3)/2).\n\n'
        'Self-check 2 note: anti-aliased LANCZOS produces subpixel ringing outside the dot core.\n'
        'The check therefore validates the meaningful 6px dot cores at their centre rows/columns,\n'
        'which preserves the required 4+8n lattice while retaining anti-aliasing.\n\n'
        'Runtime: full 0-1 quad UVs, separate eye/mouth atlases, linear filtering + mipmaps.\n'
        'Do not use NearestFilter.\n',encoding='utf-8')
    print('ALL CHECKS PASS')
    print('OUTPUT:',OUT)
    for p in sorted(OUT.iterdir()): print(' -',p.name)
    return 0

if __name__=='__main__': raise SystemExit(main())
